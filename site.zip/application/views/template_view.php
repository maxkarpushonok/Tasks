<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <title>Tasks - Test PHP MVC application</title>
    <link rel="stylesheet" type="text/css" href="/css/style.css">
</head>
<body>
<?php
    /** @var View $content_view */
    include 'application/views/'. (String) $content_view;
?>
</body>
</html>